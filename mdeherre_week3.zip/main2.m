function [ H,QDivDiff ] = main2( X,Y,YP,x )
%error statement generation
[xn,xm] = size(X);
[yn,ym] = size(Y);
[ypn,ypm] = size(YP);

    if xm ~= ym || ypm ~= xm
        error('mismatch of X and Y array lengths')
    elseif xn ~= 1 || yn ~= 1 || ypn ~= 1
        error('input and output arrays must only have one row')
    end
    
H = 0;      %initialize for sum
prod = ones(1,2*xm);    %initialize for multiplying z values
QDivDiff = zeros(2*xm-1);    %initialize size of the matrix
ZX = zeros(1,2*xm);         %zi array
ZY = zeros(1,2*xm);         %Qi,0 array

%initialize all the values for zi's and Qi,0's
for l=1:xm
    ZX(2*l-1) = X(l);
    ZX(2*l) = X(l);
    ZY(2*l-1) = Y(l);
    ZY(2*l) = Y(l);
end

%loop within a loop, creating values for the divided differences
for i=1:2*xm    %run through all z values
    for j=1:i-1
        QDivDiff(i,j) = Qdiv(ZX,ZY,YP,i,j);
        %i,j element of QDivDiff should be Qi,j
        %define QDiv next time
        prod(i) = prod(i) * (x-ZX(j));       %product of i-1 terms in the formula
    end
    
    H = H + Qdiv(ZX,ZY,YP,i,i-1)*prod(i);   %adds each term in the sum of the formula
end


end

function  d  = Qdiv(ZX,ZY,YP,i,j)
if j == 0
    d = ZY(i);
elseif j == 1 && mod(i,2) == 0
    d = YP(0.5*i);
else
    d = (Qdiv(ZX,ZY,YP,i,j-1) - Qdiv(ZX,ZY,YP,i-1,j-1))/(ZX(i)-ZX(i-j));
end
end

        
        
        
        
        