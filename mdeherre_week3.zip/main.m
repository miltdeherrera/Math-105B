X = [1, 2, 3];
Y = [1.105170918, 1.491824698, 2.459603111];
YP = [.2210341836, .5967298792, 1.475761867];

X_Pre = [1,2];
Y_Pre = [1.105170918, 1.491824698];
YP_Pre = [.2210341836, .5967298792];


disp('estimate of f(x) at x=1.25 using H_3: ')
a1 = main2(X_Pre,Y_Pre,YP_Pre,1.25)

disp('estimate of f(x) at x=1.25 using H_5: ')
a2 = main2(X,Y,YP,1.25)

disp('error for H3: ')
error = abs(a1 - exp(0.1*1.25^2))

disp('error for H5: ')
error = abs(a2 - exp(0.1*1.25^2))

syms t

f = exp(0.1*t^2);
y = sym(zeros(1,6));
y(1) = f;

for k = 2:7
    y(k) = diff(y(k-1));
end

y4thprime2 = subs(y(5),t,2);
y6thprime3 = subs(y(7),t,3);
num4 = double(y4thprime2);
num6 = double(y6thprime3);

disp('max error for H3 is: ')       % this is based on the max value of the function on the interval
error = (.25^2)*(.75^2)*num4/(4*3*2*1)

disp('max error for H5 is: ')       % this is based on the max value of the function on the interval
error = (.25^2)*(.75^2)*(1.75^2)*num6/(6*5*4*3*2*1)
