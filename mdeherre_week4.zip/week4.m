% Part one: completed below
% Part two: completed below. The Lagrange polynomial interpolant is much
% less accurate than the cubic spline interpolant at certain points. I
% believe this is because terms in the denominator "blow up" the error
% leading to spurious results.
% Part three: completed below.










% part one: function, plot
% part two:  compare f_lagrange(X,Y,x) to NaturalSpline(X,Y,x) at same
% values. Compare the plots of the functions
% part three: Compare plot of NaturalSpline with f(x)
% Max error: compare values of f(x) to spline with the max (for all x in z)
% of abs(NaturalSpline(X,Y,x) - f(x))
% theoretical error estimate: Use thm 3.13 (note: this is for the clamped
% spline, but it can be used for natural splines too)

% initializing the arrays

X = [-2.4061,-1.0830,-.6440,-.4068,-.2448,-.1158,0,.1158,.2448,.4068,.6440,1.0830,2.4061];
Y = [-.3984,-.7611,-.9688,-.9791,-.7899,-.4397,0,.4397,.7899,.9791,.9688,.7611,.3984];
x = 2;

Z = linspace(-2,2,10);

% creating an array of x-values
XSplinePoints = cat(2,X,Z);
XSplinePoints = sort(XSplinePoints);

size = numel(XSplinePoints);

YSplinePoints = zeros(1,size);
adummy = [1];
bdummy = [1];
cdummy = [1];
ddummy = [1];

for i=1:size
    [YSplinePoints(i),adummy,bdummy,cdummy,ddummy] = NaturalSpline(X,Y,XSplinePoints(i));
end

% at this point we have all the xpoints, all the ypoints for the spline
% interpolation. Now we need the same points for the Lagrange interpolation

XLagrangePoints = XSplinePoints;
YLagrangePoints = zeros(1,size);

for i=1:size
    YLagrangePoints(i) = f_lagrange2( X,Y,XLagrangePoints(i) );
end

% Now we've got the interpolation points for the Lagrange polynomial too

plot(XLagrangePoints,YLagrangePoints)
hold on
plot(XSplinePoints,YSplinePoints)
z = XSplinePoints;
Y = z./(.25+z.^2);
axis([-3,3 -1 1])
plot(z,Y);
legend('Lagrange interpolation', 'Natural spline interpolation','Actual function')


% computing max error
maxError = 0;
for i = 1:size
    if abs(YSplinePoints(i) - Y(i)) > maxError
        maxError = abs(YSplinePoints(i) - Y(i));
    end
end

disp('Max error = ')
maxError


% calculating the theoretical error: first calculating max (x_j+1 - x_j)^4

j = 0;
for i = 1:size-1
    if (XSplinePoints(i+1) - XSplinePoints(i))^4 > j
        j = (XSplinePoints(i+1) - XSplinePoints(i))^4;
    end
end


% now calculating M = max(abs(f^4(x)))

syms t

f = t/(.25+t^2);
y = sym(zeros(1,6));
y(1) = f;

for k = 2:7
    y(k) = diff(y(k-1));
end

% finding the inflection points for f^4(x)
crit_points = double(solve(y(6)));

size = numel(crit_points);

% finding the value of f^4(x) at each crit point to find the max value
% thereof
t = double(subs(y(5),crit_points(1)));

for i = 2 : size-1
    y4th = subs(y(5),crit_points(i));
    num4 = double(y4th);
    
    if num4 > t
        i;
        t = num4;
    end
end

% t = M. Now we can output the final value of the error calculation

theoreticalError = t * 5 * j / 384