function [ y ] = TrapError( a,b,n,f )
%TrapError Calculates the error for Composite Trapezoidal rule given the
%start and end points, f, and the step size

h = (b-a)/n;

% get second and third derivative of f

f2p = diff(diff(f));
f3p = diff(f2p);

% algorithm: find f^2(a) and f^2(b). Then searches for zeros of f^3 in
% (a,b). if they don't exist, highest value is max(f^2(a), f^2(b)). If they
% do, find the highest thereof, then compare to highest of f^2(a) and
% f^2(b).

t = 0;
if f2p(a) > f2p(b)
    t = f2p(a);
else
    t = f2p(b);
end

z = solve(f3p);

for i = 1:numel(z)
    if z(i) > a & z(i) < b
        if f2p(z(i)) > t
            t = f2p(z(i));
        end
    end
end

% now that we've found the highest value of f^2(x) in [a,b], we plug that
% into the overall error formula

y = (b-a)*h^2*t;
y = y/12;



end

