function [ y ] = SimpsonComp( a, b, n, f )
%SimpsonComp Computes the composite Simpson's Rule estimation for the
%integral of f over the interval [a,b]

% error check
if a >= b
    error('ERROR: a needs to be less than b.')
end

if mod(n,2) ~= 0
    error('ERROR: n needs to be even.')
end

% initializing values
h = (b-a)/n;

I0 = f(a) + f(b);
I1 = 0;
I2 = 0;

for i = 1:n-1
    x = a + i*h;
    if mod(i,2) == 0
        I2 = I2 + f(x);
    else
        I1 = I1 + f(x);
    end
end

y = (h/3) * (I0 + 2*I2 + 4*I1);

    

end

