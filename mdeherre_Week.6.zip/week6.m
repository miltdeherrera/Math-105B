% Pt 1: calculating exact value of integral from 1 to 2 of x*ln(x)
syms x
f(x) = x * log(x);
a = 1;
b = 2;

pt1integral = double(int(f, 1, 2))
fp = diff(f);
fpp = diff(fp);
fp3 = diff(fpp);
fp4 = diff(fp3);
fp5 = diff(fp4);
fp6 = diff(fp5);

% Pt 2: using trapezoidal rule and simpson's rule
% trapezoidal rule

h = b - a;
pt2trapint = double((h/2)*(f(1)+f(2)))

% finding actual error

pt2trapActError = double(abs(pt2trapint - pt1integral))

% finding theoretical error

% first find max value of fpp in [1,2] -- fpp(x) = x^-1, so max value in
% [1,2] is x = 1.

pt2trapTheoreticalError = double(h^3/12)

% Simpson's Rule

h = (b - a)/2;
pt2simpint = double((h/3)*(f(a) + 4*f(a + h) + f(b)))

% finding actual error
pt2simpActError = double(abs(pt2simpint - pt1integral))

% finding theoretical error
% max value of f4p in [1,2] = max value of 2/x^3 = 2

pt2simpTheoreticalError = double(((h^5)*2)/90)

% Pt 3: algorithms developed in SimpsonComp and TrapComp functions

% Pt 4: Plotting algorithms

n = [10, 20, 50, 100];
TrapEstArray = zeros(1,4);
SimpEstArray = zeros(1,4);

% getting points for each value of n

for i=1:4
    TrapEstArray(i) = TrapComp(a, b, n(i), f);
    SimpEstArray(i) = SimpsonComp(a, b, n(i), f);
end

figure
title('Estimates of f(x) using various approximations')
plot(n,TrapEstArray)
hold on
plot(n,SimpEstArray)
legend('Trapezoidal rule estimate', 'Simpson''s rule estimate')
xlabel('n')
ylabel('Estimated value of f(x)')

% Pt 5: graph of error estimate compared to n

n = [10, 20, 50, 100];
TrapErrorArray = zeros(1,4);
SimpErrorArray = zeros(1,4);

for i=1:4
    TrapErrorArray(i) = TrapError(a, b, n(i), f);
    SimpErrorArray(i) = SimpsonError(a, b, n(i), f);
end

figure
title('Theoretical error using various approximations')
plot(n,TrapErrorArray)
hold on
plot(n,SimpErrorArray)
legend('Trapezoidal rule estimate', 'Simpson''s rule estimate')
xlabel('n')
ylabel('Estimated value of f(x)')