function [ y ] = TrapComp( a, b, n, f )
%TrapComp Computes the composite Trapezoidal Rule estimation for the
%integral of f over the interval [a,b]

% error check
if a >= b
    error('ERROR: a needs to be less than b.')
end

% initializing values
h = (b-a)/n;

I0 = f(a);
I2 = f(b);
I1 = 0;

for i = 1:n-1
    x = a + i*h;
    I1 = I1 + f(x);
end

y = (h/2) * (I0 + 2*I1 + I2);

    

end

