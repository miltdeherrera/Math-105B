% (1): included in f_lagrange2.m
% (2): Calculate f(3) - P(3)

% setting up P(x)
n=3;
X = linspace(1,2.9,n);
Y = 1./X;

% defines f(x) = 1/x for x = 3
f = 1/3;
p = f_lagrange2(X,Y,3);
var = abs(f - p);
disp(['absolute error = ' num2str(var)]);