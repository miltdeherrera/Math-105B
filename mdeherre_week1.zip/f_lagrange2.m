function y = f_lagrange2( X,Y,x )
%f_lagrange     Computes the value of a point
%               using Lagrange interpolation method
%   X = array of X values
%   Y = array of f(X) values
%   x = the point whose value is being found

% error checking

if ~isvector(X) || ~isvector(Y)
    error('ERROR: X and/or Y is not a vector')
elseif size(X) ~= size(Y)
    error('ERROR: dimension mismatch between X and Y')
end


y = 0;        % the value of P_x, initialized

n = size(X,2);

for i = 1:n
    % determine value of L for this particular i
    L = 1;
    for j = 1:n
        if j ~= i
            L = L * (x - X(j))/(X(i) - X(j));
        end
    end
    
    y = y + Y(i)*L;
end
            



end

