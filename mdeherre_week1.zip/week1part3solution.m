% (3): Plot abs[f(3) - P(3)] for n = 3, 4, 5, 6

diff_array = zeros(2,4);   % the array with the differences

for i=3:6
    X = linspace(1,2.9,i);
    Y = 1./X;
    
    p = f_lagrange2(X,Y,3);
    diff_array(1,i-2) = i;
    diff_array(2,i-2) = abs(f - p);
end

disp(diff_array);