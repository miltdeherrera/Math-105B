% (4): Produce a single plot showing the exact function f(x)=1/x and the Lagrange interpolants using n=3, 4 and 6.
hold on
xlabel('x-axis') % x-axis label
ylabel('y-axis') % y-axis label
x = linspace(1,3,100);

for i=3:6
    X = linspace(1,2.9,i);
    Y = 1./X;
    
for i = 1:100           %finds y-values
    y(i) = f_lagrange2(X,Y,x(i))

end
    plot(x,y)
end

plot(x,1./x,'-r')  %actual function for comparison
