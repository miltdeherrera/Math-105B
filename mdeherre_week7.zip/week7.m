% week 7

% pt 1: calculate exact value of the integral

syms x
f(x) = cos(2*x)*exp(-x);
a = 0;
b = 2*pi;

exact_value = double(int(f,x,a,b))

% pt 2
% Use previous Composite Simpson's rule function

n_array = [10,20,50,100];
h_array = [2*pi/10, 2*pi/20, 2*pi/50, 2*pi/100];
CompSimpArray = [0, 0, 0, 0];

for i = 1:4
    CompSimpArray(i) = SimpsonComp( a, b, n_array(i), f );
end

SimpError = [0, 0, 0, 0];

for i = 1:4
    SimpError(i) = abs(CompSimpArray(i) - exact_value);
end


% finding theoretical error

theoreticalErrorArray = [0,0,0,0];

% now calculating actual theoretical errors
for i = 1:4
    theoreticalErrorArray(i) = SimpsonError( a,b,n_array(i),f );
end


% plotting

figure
title('Estimates of f(x) using various approximations')
plot(n_array,SimpError)
hold on
plot(n_array,theoreticalErrorArray)
legend('Actual Error', 'Theoretical error')
xlabel('n')
ylabel('Level of error')


% part three: found in AdaptSimpsonCom.m
% part four

S = double(AdaptSimpsonCom( a, b, f , .5*10^-4, 6))

% Min number of levels needed to successfully estimate with .5e-5 accuracy:
% 6 levels

% finding out number of points needed for same level of accuracy from
% composite simpson's method

accuracy_met = false;
n = 2;

while (accuracy_met ~= true)
    estimate_check = SimpsonComp( a, b, n, f );
    if abs(estimate_check - exact_value) < .5*10^-4
        accuracy_met = true;
    else
        n = n+2;
    end
end

number_of_req_points = n

% 38 points required for Composite Simpson's to achieve the same level of
% accuracy as Adaptive Quadrature.