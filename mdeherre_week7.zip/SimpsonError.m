function [ y ] = SimpsonError( a,b,n,f )
%SimpsonError Calculates the error for Composite Simpson's rule given the
%start and end points, f, and the step size

h = (b-a)/n;

% get fourth and fifth derivative of f

f4p = diff(diff(diff(diff(f))));
f5p = diff(f4p);

% algorithm: find f^4(a) and f^4(b). Then searches for zeros of f^5 in
% (a,b). if they don't exist, highest value is max(f^4(a), f^4(b)). If they
% do, find the highest thereof, then compare to highest of f^4(a) and
% f^4(b).

t = 0;
if f4p(a) < f4p(b)
    t = f4p(a);
else
    t = f4p(b);
end

z = solve(f5p);

for i = 1:numel(z)
    if double(z(i)) > a && double(z(i)) < b
        if double(f4p(z(i))) < t
            t = f4p(z(i));
        end
    end
end

% now that we've found the highest value of f^4(x) in [a,b], we plug that
% into the overall error formula

y = -(b-a)*h^4*t;
y = y/180;



end

