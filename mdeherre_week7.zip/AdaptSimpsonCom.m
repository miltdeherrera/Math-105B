function [ S ] = AdaptSimpsonCom( a, b, f , E, N)
%AdaptSimpsonComp uses the Adaptive Quadrature method to estimate the value
%of the integral of a function f over [a,b]

% error check
if a >= b
    error('ERROR: a needs to be less than b.')
end

% initialize

S = 0;
i = 1;
epsilon(i) = 10*E;
a(i) = a;
h(i) = (b-a)/2;
FA(i) = f(a);
FC(i) = f(a+h(i));
FB(i) = f(b);
S_array(i) = h(i)*(FA(i) + 4*FC(i) + FB(i)) / 3;
L(i) = 1;

% step two loop
while i > 0
    
    % step three
    
    FD = f(a(i) + h(i) / 2);
    FE = f(a(i) + 3 * h(i) / 2);
    S1 = h(i) * (FA(i) + 4*FD + FC(i)) / 6;
    S2 = h(i) * (FC(i) + 4*FE + FB(i)) / 6;
    v1 = a(i);
    v2 = FA(i);
    v3 = FC(i);
    v4 = FB(i);
    v5 = h(i);
    v6 = epsilon(i);
    v7 = S_array(i);
    v8 = L(i);
    
    % step four
    
    i = i - 1;  % deleting this level
    
    % step five
    
    if abs(S1 + S2 - v7) < v6
        S = S + S1 + S2;
    else
        if v8 >= N
            error('LEVEL EXCEEDED')
        else
            % right half of subinterval
            i = i + 1;
            a(i) = v1 + v5;
            FA(i) = v3;
            FC(i) = FE;
            FB(i) = v4;
            h(i) = v5 / 2;
            epsilon(i) = v6/2;
            S_array(i) = S2;
            L(i) = v8 + 1;
            
            % left half of subinterval
            i = i + 1;
            a(i) = v1;
            FA(i) = v2;
            FC(i) = FD;
            FB(i) = v3;
            h(i) = h(i-1);
            epsilon(i) = epsilon(i-1);
            S_array(i) = S1;
            L(i) = L(i-1);
        end
    end
end





end

